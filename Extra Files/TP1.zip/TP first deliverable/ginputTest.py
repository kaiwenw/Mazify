import pylab
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from PIL import Image

def almostEqual(x,y,epsilon=10**-6):
    return abs(x[0]-y[0])<epsilon and abs(x[1]-y[1])<epsilon

def readStartEnd(imageName):
    x1 = mpimg.imread(imageName)
    fig1 = pylab.figure(1, figsize=(11,9))
    ax1 = fig1.add_subplot(1,1,1)
    ax1.imshow(x1)
    ax1.axis('image')
    ax1.axis('off')
    print("Click start and end coords")
    x = fig1.ginput(2)
    print("click the top left and bottom right corner")
    y = fig1.ginput(2)
    XBounds = (y[0][0],y[1][0])
    YBounds = (y[0][1],y[1][1])
    return(x[0],x[1],XBounds,YBounds)


mazeFile = "maze2BW.jpg"
img = Image.open(mazeFile)
pixels = img.load()
start,end,XBounds,YBounds = readStartEnd(mazeFile)
pixels[start] = (255,0,0)
pixels[end] = (0,255,0)
img.show()