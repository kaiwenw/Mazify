import pylab
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from PIL import Image

imageName = "chrome.jpg"
img = Image.open(imageName)
pixels = img.load()

def getColor(pixels):
    x1 = mpimg.imread(imageName)
    fig1 = pylab.figure(1, figsize=(11,9))
    ax1 = fig1.add_subplot(1,1,1)
    ax1.imshow(x1)
    ax1.axis('image')
    ax1.axis('off')
    print("Click coords to find color at: ")
    coords = fig1.ginput(1)
    x,y = coords[0]
    x = int(round(x))
    y = int(round(y))
    return pixels[x,y]

print(getColor(pixels))
