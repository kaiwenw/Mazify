import matplotlib
matplotlib.use("TkAgg")
from tkinter import *
from tkinter.filedialog import *
from PIL import Image, ImageTk
from kMeansSeg import *
from mazeGenerator import *
import string


def init(data):
    data.START = 1
    data.CHOOSEMODE = 2
    data.HOW = 3
    data.GIMMICKS = 4
    data.DISPLAY = 5
    data.MAZE = 6
    data.OUTLINE = 7
    data.mode = data.START
    data.file = None
    ###errors
    data.imageError = False
    data.stepSizeError = False
    ###
    data.widthFactor,data.heightFactor = 2,2
    data.imgWidth = data.width//data.widthFactor
    data.imgHeight = data.height//data.heightFactor
    
    initImages(data)


    #print(data.photo)
    pass

#initialize img/photos and switches
def initImages(data):
    data.img,data.photo=None,None
    data.kMeansImg,data.photoOutln=None,None
    data.mazeImg,data.mazePhoto=None,None
    data.outlineSwitch = False
    data.mazeSwitch=False
    data.displaySwitch = False
    data.imageError = False
    data.kNumberError = False
    data.stepSizeError = False
    data.startPickedError = False
    data.kSize = ''
    data.stepSize=""
    data.startPosition = None
    data.drawStartPosition = None
    data.endPosition = None
    data.drawEndPosition = None


###HELPER FUNCTIONS#############################################################

def getFileName(data):
    return askopenfilename()

#resizes img and converts it to a photo
def convertImageAndResize(data):
    data.img = data.img.resize((data.width//data.widthFactor,
                    data.height//data.heightFactor), Image.ANTIALIAS)
    # print(data.img)
    return ImageTk.PhotoImage(data.img)

#Doesn't return anything, because destructive
def getImageOutline(data,iterationIndex=5):
    #this is pivotal to ensure the processing time of the program
    #img is the 200,200 image for the whole program, whereas kMeansImg and 
    #mazeImg are 400,400 respective versions
    data.img = data.img.resize((200,200),Image.ANTIALIAS)
    dataPts = getPixMatrix(data.img)
    data.kMeansImg = kMeans(5,dataPts,data.img,iterationIndex=iterationIndex)
    data.kMeansImg = data.kMeansImg.resize((data.width//data.widthFactor,
                                data.height//data.heightFactor),Image.ANTIALIAS)
    data.photoOutln = ImageTk.PhotoImage(data.kMeansImg)
    # print(data.kMeansImg)

def getMaze(data):

    data.mazeImg = generateMaze(data.img,int(data.stepSize),data.startPosition)
    data.mazeImg = data.mazeImg.resize((data.width//data.widthFactor,
                                data.height//data.heightFactor),Image.ANTIALIAS)
    data.mazePhoto = ImageTk.PhotoImage(data.mazeImg)
    # print(data.mazeImg)

#pops up window when processing
def processingPleaseWait(text, function, *args):
    import time, threading
    window = Toplevel() 
    label = Label(window, text = text)
    label.pack()
    done = []
    def call():
        result = function(*args)
        done.append(result)

    thread = threading.Thread(target = call)
    thread.start() # start parallel computation
    while thread.is_alive():
        # code while computing
        window.update()
        time.sleep(0.001)
    # code when computation is done
    label['text'] = str(done)


################################################################################

def mousePressed(event, data):
    # use event.x and event.y
    #TODO: USE event.xy to find start instead of matplotlib
    #Images top edge is at height//5
    if(data.mode==data.OUTLINE):
        yShift = data.height//5
        xShift = (data.width-data.imgWidth)/2
        (x,y) = (event.x-xShift,event.y-yShift)
        xFactor = data.imgWidth/200
        yFactor = data.imgHeight/200
        if(0<=x<=data.imgWidth and 0<=y<=data.imgHeight):
            data.startPosition = (int(x/xFactor),int(y/yFactor))
            data.drawStartPosition = (event.x,event.y)
    elif(data.mode==data.MAZE):
        yShift = data.height//5
        xShift = (data.width-data.imgWidth)/2
        (x,y) = (event.x-xShift,event.y-yShift)
        xFactor = data.imgWidth/200
        yFactor = data.imgHeight/200
        if(0<=x<=data.imgWidth and 0<=y<=data.imgHeight):
            data.endPosition = (int(x/xFactor),int(y/yFactor))
            data.drawEndPosition = (event.x,event.y)
    pass

def keyPressed(event, data):
    ####START SPLASH SCREEN
    if(data.mode==data.START):
        if(event.keysym=="p"):
            data.mode=data.CHOOSEMODE
        elif(event.keysym=='h'):
            data.mode=data.HOW
        elif(event.keysym=='g'):
            data.mode=data.GIMMICKS

    #CHOOSE PICTURE
    elif(data.mode==data.CHOOSEMODE):
        if(event.keysym=="b"):
            data.mode=data.START
            data.imageError=False
        elif(event.keysym=="c"):
            data.file = getFileName(data)
            #safety measure
            if(not data.file.endswith(".gif") and not data.file.endswith(".png")\
                 and not data.file.endswith(".jpg")): 
                data.imageError = True
                return
            data.img = Image.open(data.file)
            data.photo = convertImageAndResize(data)
            data.mode = data.DISPLAY

    #DISPLAY PICTURE
    elif(data.mode==data.DISPLAY):
        if(event.keysym=="b" or event.keysym=="n"):
            data.mode=data.CHOOSEMODE
            data.file=None
            data.timer=0
            initImages(data)
        elif(event.keysym in string.digits):
            data.kSize += event.keysym
            data.kNumberError = False
        elif(event.keysym == "d"):
            data.kSize = data.kSize[0:-1]
        elif(data.kSize==""):
            data.kNumberError = True
            return
        elif(event.keysym=="y"):
            data.mode=data.OUTLINE
            ###NEEDS TO CREATE LOADING SCREEN###
            if(data.outlineSwitch==False):
                processingPleaseWait("...please wait",getImageOutline,data)
                #getImageOutline(data)
                data.outlineSwitch = True

    #OUTLINE MODE
    elif(data.mode==data.OUTLINE):
        if(event.keysym=="b" or event.keysym=='n'):
            data.mode = data.CHOOSEMODE
            data.file=None
            data.timer=0
            initImages(data)
        elif(event.keysym in string.digits):
            data.stepSize += event.keysym
            data.stepSizeError = False
        elif(event.keysym == "d"):
            data.stepSize = data.stepSize[0:-1]
        elif(data.stepSize==""):
            data.stepSizeError = True
            return
        elif(data.startPosition==None):
            data.startPickedError = True
            return
        elif(event.keysym=="y"):
            data.mode=data.MAZE
            #generate maze
            # data.mazePhoto = processingPleaseWait("...please wait",
            #             test,data.img,int(data.stepSize),data.file)
            if(data.mazeSwitch==False):
                processingPleaseWait("...please wait",getMaze,data)
                #getMaze(data)
                data.mazeSwitch = True
            pass
    #MAZE MODE
    elif(data.mode==data.MAZE):
        if(event.keysym=="b"):
            data.mode = data.CHOOSEMODE
            data.file=None
            data.timer=0
            initImages(data)
        if(event.keysym=="m"):
            #segment through k-means
            pass
    #HOW TO PLAY
    elif(data.mode==data.HOW):
        if(event.keysym=="b"):
            data.mode=data.START
    #GIMMICKS
    elif(data.mode==data.GIMMICKS):
        if(event.keysym=='b'):
            data.mode=data.START
    pass

def timerFired(data):

    pass


####DRAW MODES######
def drawSplashScreen(canvas,data):
    Title = "Kevin's MazeGen"
    canvas.create_text(data.width//2,data.height//4,text=Title,font="Arial 40 bold")
    canvas.create_text(data.width//2,data.height//2,text = "Press P to Play",font="Arial 30 italic")
    canvas.create_text(data.width//2,data.height*2//3,text = "Press H for Help",font="Arial 30 italic")
    canvas.create_text(data.width//2,data.height*5//6,text = "Press G for Gimmicks",font="Arial 30 italic")

def drawChooseMode(canvas,data):
    Title = "Play Mode"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//6,text=Title,font="Arial 40 bold")
    canvas.create_text(data.width//2,data.height//2,
            text="Press c to choose file",font="Arial 30 bold")
    canvas.create_text(data.width//2,data.height*3//4,
        text="Press s to google search file",font="Arial 30 bold")
    if(data.imageError):
        canvas.create_text(data.width//2,data.height*2//3,
            text="Please use an image (.gif,.png,.jpg) file",
            font="Arial 20 bold", fill="red")

def drawDisplay(canvas,data):
    Title = "Display Mode"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//6,text=Title,font="Arial 40 bold")
    #simulate loading screen
    canvas.create_text(data.width//2,data.height*5//6,text=str(data.kSize),
                font="Arial 20",fill="blue")
    if(data.kNumberError):
        canvas.create_text(data.width//2,data.height*5//6,
            text="Please input a valid stepsize before continuing",
                    font="Arial 20 bold",fill="blue")

    canvas.create_text(data.width//2,data.height*4//5,
        text="Select Number of Colors (2-9), Press d to delete",font="Arial 20 bold")
    canvas.create_image(data.width//2,data.height//5,image=data.photo,anchor="n")
    canvas.create_text(data.width//2,data.height*6//7,
        text="Is this right image? (Y/N)",font="Arial 20 bold",fill="red")

def drawRightOutline(canvas,data):
    Title = "Outline Mode"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//6,text=Title,font="Arial 40 bold")
    
    canvas.create_text(data.width//2,data.height*5//6,text=str(data.stepSize),
                font="Arial 20",fill="blue")
    #loading
    if(data.outlineSwitch==False):
        canvas.create_text(data.width//2,data.height//2,text="loading...",font="Arial 15 bold")
    else:
        canvas.create_text(data.width//2,data.height*4//5,
            text="Select Step Size (2-9), Press d to delete",font="Arial 20 bold")
        canvas.create_image(data.width//2,data.height//5,image=data.photoOutln,anchor="n")
        canvas.create_text(data.width//2,data.height*6//7,
            text="Is this right segmentation? Yes!/No,try again... (Y/N)",font="Arial 20 bold",fill="red")
        if(data.startPosition==None and data.drawStartPosition==None):
            canvas.create_text(data.width//2,data.height*3//4,
                text="Please pick a start Position for the maze...",
                        font="Arial 20 bold",fill="blue")
        else:
            x,y = data.drawStartPosition
            canvas.create_oval(x-3,y-3,x+3,y+3,fill="blue")
        if(data.stepSizeError):
            canvas.create_text(data.width//2,data.height*5//6,
                text="Please input a valid stepsize before continuing",
                        font="Arial 20 bold",fill="blue")


def drawMazeMode(canvas,data):
    Title = "Maze Mode! :-)"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//6,text=Title,font="Arial 40 bold")
###DISPLAYING MAZE
    if(data.mazeSwitch==False):
        canvas.create_text(data.width//2,data.height//2,text="loading...",font="Arial 20 bold")
    else:
        canvas.create_image(data.width//2,data.height//5,image=data.mazePhoto,anchor = "n")
        x,y = data.drawStartPosition
        canvas.create_oval(x-3,y-3,x+3,y+3,fill="blue")
        if(data.endPosition==None and data.drawEndPosition==None):
            canvas.create_text(data.width//2,data.height*3//4,
                text="Please pick an end Position for the maze...",
                        font="Arial 20 bold",fill="blue")
        else:
            x,y = data.drawEndPosition
            canvas.create_oval(x-3,y-3,x+3,y+3,fill="blue")

def drawHelpMode(canvas,data):
    Title = "How to Play"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//4,text=Title,font="Arial 40 bold")

def drawGimmicks(canvas,data):
    Title = "Gimmicks"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//4,text=Title,font="Arial 40 bold")


def redrawAll(canvas, data):
    if(data.mode==data.START):
        drawSplashScreen(canvas,data)
    elif(data.mode==data.CHOOSEMODE):
        drawChooseMode(canvas,data)
    elif(data.mode==data.HOW):
        drawHelpMode(canvas,data)
    elif(data.mode==data.GIMMICKS):
        drawGimmicks(canvas,data)
    elif(data.mode==data.DISPLAY):
        drawDisplay(canvas,data)
    elif(data.mode==data.OUTLINE):
        drawRightOutline(canvas,data)
    elif(data.mode==data.MAZE):
        drawMazeMode(canvas,data)
    pass

####################################
# use the run function as-is
####################################

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 100 # milliseconds
    # create the root and the canvas
    root = Tk()
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    init(data)
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

run(800, 800)
