from PIL import Image, ImageFilter
import pylab
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import random
from kMeansSeg import *



def getStartEnd(fileName):
    x1 = mpimg.imread(fileName)
    fig1 = pylab.figure(1, figsize=(11,9))
    ax1 = fig1.add_subplot(1,1,1)
    ax1.imshow(x1)
    ax1.axis('image')
    ax1.axis('off')
    print("Click start coords")
    x = fig1.ginput(1)
    return x[0]

#turns 2D array into a set
def setOfMatrix(matrix):
    result = set()
    for row in matrix:
        result = result.union(set(row))
    return result

def callWithLargeStack(f,*args):
    import sys
    import threading
    sys.setrecursionlimit(2**14) # max recursion depth of 16384
    isWindows = (sys.platform.lower() in ["win32", "cygwin"])
    if (not isWindows): return f(*args) # sadness...
    threading.stack_size(2**27)  # 64MB stack
    # need new thread to get the redefined stack size
    def wrappedFn(resultWrapper): resultWrapper[0] = f(*args)
    resultWrapper = [None]
    #thread = threading.Thread(target=f, args=args)
    thread = threading.Thread(target=wrappedFn, args=[resultWrapper])
    thread.start()
    thread.join()
    return resultWrapper[0]

#Weak but faster way of image segmentation than k-means
#use ONLY for monotonic images with sharp colors
def mazeFill(img,pixels,threshold=255/2):
    width,height = img.size
    threshold = 255/2
    for x in range(width):
        for y in range(height):
            r,g,b = pixels[x,y]
            if(r>threshold): r = 255
            else: r = 0
            if(g>threshold): g = 255
            else: g = 0
            if(b>threshold): b = 255
            else: b = 0
            pixels[x,y] = r,g,b

#Gets rid of impure pixels in the filtered image 
def clearImpurities(img,pixels,blobRange=1):
    width,height = img.size
    def isLegal(x,y):
        if(x<0 or x>=width or y<0 or y>=height):
            return False
        else:
            return True
    for x in range(width):
        for y in range(height):
            colorsDict = dict()
            mostFreqColor = None
            mostFreqCount = 0
            color = pixels[x,y]
            colorsDict[color] = 1
            #should be adjustible blob analysis range
            for dx in range(-blobRange,blobRange+1):
                for dy in range(-blobRange,blobRange+1):
                    if(isLegal(x+dx,y+dy)):
                        newColor = pixels[x+dx,y+dy]
                        colorsDict[newColor] = colorsDict.get(newColor,0) + 1
                        if(mostFreqCount<colorsDict[newColor]):
                            mostFreqCount = colorsDict[newColor]
                            mostFreqColor = newColor
            pixels[x,y] = mostFreqColor

#Creates a connectedMatrix that specifies the connectivity of colors
#TODO: DICTIONARY OF key (start position and color) corresponding to position of all pixels in the block
def splitToSections(img,pixels):
    width,height = img.size
    connectedMatrix = [[None]*width for row in range(height)]
    #to distinguish blocks of same color
    #blockCount = 1
    def colorFill(pixels, x, y, connectedMatrix, colorToMatch):
        #off board
        global testList
        if ((x < 0) or (x >= width) or
            (y < 0) or (y >= height)):
            return
        
        #already connected
        if (connectedMatrix[y][x]!=None):
            return

        print(x,y,colorToMatch)
        testList.append((x,y))

        # "fill" this cell
        color = pixels[x,y]
        if(color == colorToMatch):
            connectedMatrix[y][x] = colorToMatch
            #recursively check neighbours
            colorFill(pixels, x, y+1, connectedMatrix, colorToMatch) #down
            colorFill(pixels, x, y-1, connectedMatrix, colorToMatch) #up
            colorFill(pixels, x-1, y, connectedMatrix, colorToMatch) #left
            colorFill(pixels, x+1, y, connectedMatrix, colorToMatch) #right

    for x in range(width):
        for y in range(height):
            colorToMatch = pixels[x,y]
            #background is white
            if connectedMatrix[y][x]==None and colorToMatch!=(255,255,255):                

                colorFill(pixels,x,y,connectedMatrix,
                                    colorToMatch)
    return connectedMatrix

#only shows the ShowThis color
def filterColor(showThis):
    for x in range(width):
        for y in range(height):
            if(connectedMatrix[y][x]!=showThis):
                pixels[x,y] = (255,255,255)

###MAZE MAKING####
class Struct(object): pass

def makeIsland(number):
    island = Struct()
    island.east = island.south = False
    island.number = number
    return island

#make a blank maze inside the object
def makeBlankMaze(img,pixels,connectedMatrix,background = None, step=1):
    width,height = img.size
    rows,cols = len(connectedMatrix),len(connectedMatrix[0])
    #islands is a dictionary of values, with a coord 
    #corresponding to an island struct
    islands = dict()
    counter = 0
    for row in range(0,rows,step):
        for col in range(0,cols,step):
            #If it is a valid cell, make an island here
            if(connectedMatrix[row][col]!=background):
                islands[(col,row)] = makeIsland(counter)
                counter+=1
    return islands,counter

#connect the islands
def connectIslands(islands,numberOfIslands,step=1):
    #should make it such that it's the number of valid moves
    numberOfIslands = len(islands)
    for i in range(numberOfIslands+500):
        makeBridge(islands,step)

def makeBridge(islands,step=1):
    global connectedMatrix, listOfCoords
    #print((listOfCoords))
    while True:
        #row,col = random.randint(0,rows-1),random.randint(0,cols-1)
        #coords flipped x,y = col,row
        #col,row = random.choice(list(islands.keys()))
        col,row = random.choice(listOfCoords)
        if (col+step==200 or connectedMatrix[row][col+step]==None) and \
            (row+step==200 or connectedMatrix[row+step][col]==None):
            return
        start = islands[(col,row)]
        if flipCoin(): #try to go east
            #hit a wall: if going east isn't valid, i.e. next value is different
            if col+step==200 or connectedMatrix[row][col+step]==None: 
                print(col,row)
                print('1')
                continue
            target = islands[(col+step,row)]
            if start.number==target.number: 
                print('2')
                continue
            #the bridge is valid, so 1. connect them and 2. rename them
            start.east = True
            #renameIslands(start,target,islands)
        else: #try to go south
            if row+step == 200 or connectedMatrix[row+step][col]==None: 
                print(col,row)
                print('3')
                continue
            target = islands[(col,row+step)]
            if start.number==target.number: 
                print('4')
                continue
            #the bridge is valid, so 1. connect them and 2. rename them
            start.south = True
            #renameIslands(start,target,islands)
        #only got here if a bridge was made
        renameIslands(start,target,islands,listOfCoords)
        listOfCoords.remove((col,row))
        return

def renameIslands(i1,i2,islands,listOfCoords):
    n1,n2 = i1.number,i2.number
    lo,hi = min(n1,n2),max(n1,n2)
    for coords in listOfCoords:
            if islands[coords].number==hi: 
                islands[coords].number=lo

def flipCoin():
    return random.choice([True, False])

def makeBlankGrid(islands, step=1):
    NORTH = (0,-step)
    SOUTH = (0,+step)
    EAST = (+step,0)
    WEST = (-step,0)
    directions = [SOUTH,EAST]
    bridges = list()
    #finds all possible islands, and finds all possible connections between them
    for (col,row) in islands:
        for (dcol,drow) in directions:
            if (col+dcol,row+drow) in islands:
                #bridges in format [...{(starting x,y), ending(x,y)}...]
                #store in sets so order doesn't matter
                if({(col,row),(col+dcol,row+drow)} not in bridges):
                    bridges.append({(col,row),(col+dcol,row+drow)})
    return bridges

def drawBridges(pixels,bridges,background=None):
    def isValid(x,y):
        return pixels[x,y]!=background
    def drawBridge(pixels,bridge):
        bridge = list(bridge)
        startX,startY = bridge[0][0], bridge[0][1]
        endX,endY = bridge[1][0],bridge[1][1]
        if(endX<startX or endY<startY):
            startX,endX = endX,startX
            startY,endY = endY,startY
        difX, difY = endX-startX, endY-startY
        if(difX==0):
            for dy in range(difY):
                if(isValid(startX,startY+dy)):
                    pixels[startX,startY+dy] = (255,0,0)
        elif(difY==0):
            for dx in range(difX):
                if(isValid(startX+dx,startY)):
                    pixels[startX+dx,startY] = (255,0,0)

    for bridge in bridges:
        drawBridge(pixels,bridge)

def createMazeFromGrid(islands,bridges,start,step=1):
    NORTH = (0,-step)
    SOUTH = (0,+step)
    EAST = (+step,0)
    WEST = (-step,0)
    directions = [NORTH,SOUTH,WEST,EAST]
    startX,startY = start
    startX,startY = step*int(startX/step),step*int(startY/step)
    solutionBridges = set()
    mazeBridges = list()
    #We can know if the cells are already connected if they are in the same set.
    visited = set()
    cellStack = list()
    def isValid(x,y,direction):
        dx,dy = direction
        return({(x,y),(x+dx,y+dy)} in bridges)

    def possibleDirections(x,y,visited, bridges):
        nonlocal directions
        possible = list()
        for dx,dy in directions:
            if(((x+dx,y+dy) not in visited) and ({(x,y),(x+dx,y+dy)} in bridges)):
                possible.append((dx,dy))
        return possible

    def createMaze(x,y):
        nonlocal directions, mazeBridges, bridges, visited, cellStack
        visited.add((x,y))
        cellStack.append((x,y))
        #when there are still bridges left over OR cellstack is empty, meaning returned to the beginning
        while(len(bridges)!=1 and len(cellStack)>0):
            #has neighbours that aren't visited yet
            x,y = cellStack[-1]
            if(len(possibleDirections(x,y,visited,bridges))!=0):
                dx,dy = random.choice(possibleDirections(x,y,visited,bridges))
                mazeBridges.append({(x,y),(x+dx,y+dy)})
                bridges.remove({(x,y),(x+dx,y+dy)})
                x,y = x+dx, y+dy
                cellStack.append((x,y))
                visited.add((x,y))
                continue
            #backtrack until has possible directions
            else:
                cellStack.pop()
                continue

        return mazeBridges
    return createMaze(startX,startY)

# fileName = "pictures/doghero.jpg"
# img = Image.open(fileName)
# img = img.resize((200,200), Image.ANTIALIAS)
# width,height = img.size


def test(img,step,fileName):
    #INITIALIZING

    #originalsize = img.size
    
    if(img.mode!="RGB"):
        img = img.convert("RGB")

    #good for downsizing
    img = img.resize((200,200), Image.ANTIALIAS)
    #print(img.size)

    width,height = img.size
    pixels = img.load()

    #ImageProcessing
    # mazeFill(img,pixels)
    # clearImpurities(img,pixels)

    dataPts = getPixMatrix(img)
    kMeans(2,dataPts,img,iterationIndex = 2)

    #img.show()

    #TODO:::: ISSUE WITH even 200x200 for circle hole
    #connectedMatrix = (callWithLargeStack(splitToSections,img,pixels))
    connectedMatrix = getPixMatrix(img)
    background = connectedMatrix[0][0]
    #print(connectedMatrix)
    #return
    #make maze!
    islands,numberOfIslands = makeBlankMaze(img,pixels,connectedMatrix,
                    background=background,step=step)

    bridges = makeBlankGrid(islands, step=step)
    #drawBridges(pixels,bridges)

    #get Start and End of Maze
    #start = getStartEnd(fileName)
    #TODO: Check if start,end are valid
    start,end = (150.0, 80.0),(108.0, 121.0)

    mazeBridges = createMazeFromGrid(islands,bridges,start,step=step)
    drawBridges(pixels,mazeBridges)


    #clearer upsizing: perhaps upsize when displaying
    #img = img.resize((1024,1024),Image.ANTIALIAS)

    return img



def generateMaze(img,step,startPos):

    #img = img.resize((200,200), Image.ANTIALIAS)
    
    width,height = img.size
    pixels = img.load()

    # dataPts = getPixMatrix(img)
    # kMeans(2,dataPts,img,iterationIndex = 2)

    connectedMatrix = getPixMatrix(img)
    background = connectedMatrix[0][0]
    
    #make maze!
    islands,numberOfIslands = makeBlankMaze(img,pixels,connectedMatrix,
                    background=background,step=step)

    bridges = makeBlankGrid(islands, step=step)
    #drawBridges(pixels,bridges)

    #get Start and End of Maze
    #TODO: Check if start,end are valid
    start = startPos
    print(start)

    mazeBridges = createMazeFromGrid(islands,bridges,start,step=step)
    drawBridges(pixels,mazeBridges)


    #clearer upsizing: perhaps upsize when displaying
    #img = img.resize((1024,1024),Image.ANTIALIAS)

    return img


#img=Image.open("pictures/dog2.png")

def solveMaze(startX,startY,endX,endY,maze,bridges,step):
    maze = data.maze
    solveVisited = set()
    startX,startY = step*int(startX/step),step*int(startY/step)
    endX,endY = step*int(endX/step),step*int(endY/step)
    NORTH = (0,-step)
    SOUTH = (0,+step)
    EAST = (+step,0)
    WEST = (-step,0)
    def isValid(data,x,y,dx,dy):
        if(connectedMatrix[x][y]==background):
            return False
        if direction==EAST: return {(x,y),(x+dx,y)} in bridges
        if direction==SOUTH: return {(x,y),(x,y+dy)} in bridges
        if direction==WEST: return {(x,y),(x-dx,y)} in bridges
        if direction==NORTH: return {(x,y),(x,y-dx)} in bridges
        assert False
    def solve(x,y):
        # base cases
        if (row,col) in solveVisited: return False
        solveVisited.add((row,col))
        if (row,col)==(targetRow,targetCol): return True
        # recursive case
        for dx,dy in [NORTH,SOUTH,EAST,WEST]:
            if isValid(data, x,y,dx,dy):
                if solve(x+dx,y+dy): return True
        solveVisited.remove((x,y))
        return False
    return solveVisited if solve(data.startX,data.startY) else None

# img=Image.open("pictures/dog2.png")
# dataPts = getPixMatrix(img)
# kImg = kMeans(5,dataPts,img,iterationIndex = 2)
# print(kImg)
# #testList = []
# mazeImg = generateMaze(kImg,3)
# mazeImg = mazeImg.resize((400,400),Image.ANTIALIAS)
# mazeImg.save('testMazeSolver.jpg')
# print(mazeImg)
# mazeImg.show()

# img = Image.open("testMazeSolver.jpg")
# img1 = img.filter(ImageFilter.SHARPEN)
# img.show()
# img1.show()

