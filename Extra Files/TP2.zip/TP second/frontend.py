import matplotlib
matplotlib.use("TkAgg")
from tkinter import *
from tkinter.filedialog import *
from PIL import Image
from kMeansSeg import *
from mazeGenerator import *


def init(data):
    data.START = 1
    data.CHOOSEMODE = 2
    data.HOW = 3
    data.GIMMICKS = 4
    data.DISPLAY = 5
    data.MAZE = 6
    data.mode = data.START
    data.file = None
    data.buttonStatus = False
    data.error = False
    data.photo = None
    print(data.photo)
    data.timer = 0
    #print(data.photo)
    pass

def mousePressed(event, data):
    # use event.x and event.y
    pass


###HELPER FUNCTIONS

def getFileName(data):
    return askopenfilename()

def convertImageToOutGif(data,widthFactor,heightFactor,outName = "out.gif"):
    img = Image.open(data.file)
    img = img.resize((data.width//widthFactor,data.height//heightFactor), Image.ANTIALIAS)
    img.save(outName)
    return outName

##HELPER FUNCTIONS

def keyPressed(event, data):
    # use event.char and event.keysym
    ####START SPLASH SCREEN
    if(data.mode==data.START):
        if(event.keysym=="p"):
            data.mode=data.CHOOSEMODE
        elif(event.keysym=='h'):
            data.mode=data.HOW
        elif(event.keysym=='g'):
            data.mode=data.GIMMICKS
    #CHOOSE PICTURE
    elif(data.mode==data.CHOOSEMODE):
        if(event.keysym=="b"):
            data.mode=data.START
        elif(event.keysym=="c"):
            data.file = getFileName(data)
            #safety measure
            if(not data.file.endswith(".gif") and not data.file.endswith(".png") and not data.file.endswith(".jpg")): 
                data.error = True
                return
            data.file = convertImageToOutGif(data,2,2)
            data.photo = PhotoImage(file=data.file)
            data.mode = data.DISPLAY
    #DISPLAY PICTURE
    elif(data.mode==data.DISPLAY):
        if(event.keysym=="b" or event.keysym=="n"):
            data.mode=data.CHOOSEMODE
            data.file=None
            data.timer=0
        elif(event.keysym=="y"):
            data.mode=data.MAZE
    #MAZE MODE
    elif(data.mode==data.MAZE):
        if(event.keysym=="b"):
            data.mode=data.DISPLAY
    #HOW TO PLAY
    elif(data.mode==data.HOW):
        if(event.keysym=="b"):
            data.mode=data.START
    #GIMMICKS
    elif(data.mode==data.GIMMICKS):
        if(event.keysym=='b'):
            data.mode=data.START
    pass

def timerFired(data):
    if(data.mode==data.DISPLAY):
        if(data.file!=None):
            data.timer += 1
    pass


####DRAW MODES######
def drawSplashScreen(canvas,data):
    Title = "Kevin's MazeGen"
    canvas.create_text(data.width//2,data.height//4,text=Title,font="Arial 40 bold")
    canvas.create_text(data.width//2,data.height//2,text = "Press P to Play",font="Arial 30 italic")
    canvas.create_text(data.width//2,data.height*2//3,text = "Press H for Help",font="Arial 30 italic")
    canvas.create_text(data.width//2,data.height*5//6,text = "Press G for Gimmicks",font="Arial 30 italic")

def drawChooseMode(canvas,data):
    Title = "Play Mode"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//6,text=Title,font="Arial 40 bold")
    canvas.create_text(data.width//2,data.height//3,text="Select Complexity",font="Arial 30 bold")
    canvas.create_text(data.width//2,data.height//2,text="Press c to choose file",font="Arial 30 bold")
    canvas.create_text(data.width//2,data.height*3//4,text="Press s to google search file",font="Arial 30 bold")
    if(data.error):
        canvas.create_text(data.width//2,data.height*2//3,
            text="Please use an image (.gif,.png,.jpg) file",
            font="Arial 20 bold", fill="red")

def drawDisplay(canvas,data):
    Title = "Display Mode"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//6,text=Title,font="Arial 40 bold")
    #simulate loading screen
    canvas.create_text(data.width//2,data.height//2,text="loading...",font="Arial 20 bold")
    #0.5 second delay
    if(data.timer>5):    
        #print(data.photo)
        canvas.create_image(data.width//2,data.height//2,image=data.photo)
        canvas.create_text(data.width//2,data.height*6//7,
            text="Is this right image? (Y/N)",font="Arial 30 bold",fill="red")

def drawMazeMode(canvas,data):
    Title = "Maze Mode"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//6,text=Title,font="Arial 40 bold")
    

def drawHelpMode(canvas,data):
    Title = "How to Play"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//4,text=Title,font="Arial 40 bold")

def drawGimmicks(canvas,data):
    Title = "Gimmicks"
    canvas.create_text(20,20,text="Press b to go back",font="Arial 20",anchor="w")
    canvas.create_text(data.width//2,data.height//4,text=Title,font="Arial 40 bold")


def redrawAll(canvas, data):
    if(data.mode==data.START):
        drawSplashScreen(canvas,data)
    elif(data.mode==data.CHOOSEMODE):
        drawChooseMode(canvas,data)
    elif(data.mode==data.HOW):
        drawHelpMode(canvas,data)
    elif(data.mode==data.GIMMICKS):
        drawGimmicks(canvas,data)
    elif(data.mode==data.DISPLAY):
        drawDisplay(canvas,data)
    elif(data.mode==data.MAZE):
        drawMazeMode(canvas,data)
    pass

####################################
# use the run function as-is
####################################

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 100 # milliseconds
    # create the root and the canvas
    root = Tk()
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    init(data)
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

run(800, 800)
